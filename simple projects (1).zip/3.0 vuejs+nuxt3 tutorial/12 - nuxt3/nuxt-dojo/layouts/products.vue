<template>
    <div>
        <header class="shadow-sm bg-whie">
            <nav class="container mx-auto p-4">
                <NuxtLink to="/products" class="font-bold">Nuxt Dojo Merch</NuxtLink>
            </nav>
        </header>

                <!--output the page content-->
        <div class="container mx-auto">
            <slot />
        </div>
        <footer class="container mx-auto p-4 flex justify-between border-t-2">
            <ul class="flex gap-4">
                <li><NuxtLink to="/">Home</NuxtLink></li>
                <li><NuxtLink to="/about">About</NuxtLink></li>
                <li><NuxtLink to="/products">products</NuxtLink></li>
            </ul>
        </footer>
    </div>

</template>
<style scoped>
  .router-link-exact-active {
    color: #12b488;
  }
</style>