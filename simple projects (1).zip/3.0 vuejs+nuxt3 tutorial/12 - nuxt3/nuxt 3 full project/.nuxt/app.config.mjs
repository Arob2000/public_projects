
import { defuFn } from 'C:/Users/Eyasb/OneDrive/Desktop/EyasProjects/3.0 vuejs+nuxt3 tutorial/12 - nuxt3/nuxt 3 full project/node_modules/defu/dist/defu.mjs'

const inlineConfig = {}



export default defuFn(inlineConfig)
