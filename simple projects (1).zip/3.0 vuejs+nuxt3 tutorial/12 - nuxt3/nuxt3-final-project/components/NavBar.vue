<template>
    <header
    class="sticky top-0 z-50 flex justify-between items-center space-x-1 border-b bg-white p-4 shadow-md"
  >
    <Nuxt-link class="text-3xl font-mono" to="/">car trader</Nuxt-link>
  </header>
</template>